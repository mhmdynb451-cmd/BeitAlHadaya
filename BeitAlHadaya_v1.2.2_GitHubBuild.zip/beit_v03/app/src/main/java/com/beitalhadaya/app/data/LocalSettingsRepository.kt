package com.beitalhadaya.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

class LocalSettingsRepository : SettingsRepository {
    private val settings = MutableStateFlow(StoreSettings())
    override fun observeSettings(): Flow<StoreSettings> = settings
    override suspend fun updateSettings(settings: StoreSettings) { this.settings.value = settings }
    override suspend fun refresh() = Unit
}
