package com.beitalhadaya.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

class LocalCatalogRepository : CatalogRepository {
    private val categories = MutableStateFlow(seedCategories())
    private val products = MutableStateFlow(emptyList<Product>())

    override fun observeCategories(): Flow<List<Category>> = categories
    override fun observeProducts(): Flow<List<Product>> = products
    override suspend fun refresh() = Unit

    private fun seedCategories(): List<Category> = listOf(
        Category("women", "ملابس حريمي", "أزياء وملابس للسيدات", "women", 1),
        Category("men", "ملابس رجالي", "ملابس رجالية متنوعة", "men", 2),
        Category("kids", "ملابس أطفال", "ملابس ومستلزمات الأطفال", "kids", 3),
        Category("shoes", "الأحذية", "أحذية للنساء والرجال والأطفال", "shoes", 4),
        Category("school", "مستلزمات المدارس", "مستلزمات الدراسة والمدرسة", "school", 5),
        Category("accessories", "إكسسوارات", "إكسسوارات وهدايا صغيرة", "accessories", 6),
        Category("gifts", "الهدايا", "هدايا وبوكسات مميزة", "gifts", 7),
        Category("home", "مستلزمات المنزل", "احتياجات منزلية متنوعة", "home", 8),
        Category("beauty", "العناية والجمال", "منتجات العناية والتجميل", "beauty", 9),
        Category("appliances", "الأجهزة الكهربائية", "أجهزة وأدوات كهربائية", "appliances", 10)
    )
}
