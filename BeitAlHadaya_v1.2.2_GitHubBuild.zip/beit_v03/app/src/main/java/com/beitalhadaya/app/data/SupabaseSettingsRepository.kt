package com.beitalhadaya.app.data

import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.jsonPrimitive

@Serializable
private data class StoreSettingRow(
    val key: String,
    val value: JsonElement
)

class SupabaseSettingsRepository(
    private val fallback: SettingsRepository = LocalSettingsRepository()
) : SettingsRepository {
    private val settings = MutableStateFlow(StoreSettings())

    override fun observeSettings(): Flow<StoreSettings> = settings

    override suspend fun updateSettings(settings: StoreSettings) {
        this.settings.value = settings
    }

    override suspend fun refresh() = withContext(Dispatchers.IO) {
        runCatching {
            val rows = SupabaseClientProvider.client
                .from("store_settings")
                .select()
                .decodeList<StoreSettingRow>()
            val map = rows.associateBy { it.key }

            fun number(key: String, fallbackValue: Int): Int =
                map[key]?.value?.jsonPrimitive?.doubleOrNull?.toInt() ?: fallbackValue

            fun bool(key: String, fallbackValue: Boolean): Boolean =
                map[key]?.value?.jsonPrimitive?.booleanOrNull ?: fallbackValue

            fun text(key: String, fallbackValue: String): String =
                map[key]?.value?.jsonPrimitive?.contentOrNull ?: fallbackValue

            settings.value = StoreSettings(
                shippingFee = number("default_shipping_fee_egp", settings.value.shippingFee),
                codDeposit = number("cod_commitment_fee_egp", settings.value.codDeposit),
                currency = if (text("currency", "EGP") == "EGP") "ج.م" else text("currency", settings.value.currency),
                guestCheckoutEnabled = true,
                notificationsEnabled = true,
                codEnabled = bool("cod_enabled", true),
                visaEnabled = bool("visa_enabled", true),
                vodafoneCashEnabled = bool("vodafone_cash_enabled", true)
            )
        }.onFailure {
            fallback.refresh()
            settings.value = fallback.observeSettings().first()
        }
    }
}
