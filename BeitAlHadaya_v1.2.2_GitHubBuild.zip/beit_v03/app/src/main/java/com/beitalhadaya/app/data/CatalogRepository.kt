package com.beitalhadaya.app.data

import kotlinx.coroutines.flow.Flow

interface CatalogRepository {
    fun observeCategories(): Flow<List<Category>>
    fun observeProducts(): Flow<List<Product>>
    suspend fun refresh()
}
