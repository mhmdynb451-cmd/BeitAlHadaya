package com.beitalhadaya.app.data

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.storage.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

@Serializable
private data class CategoryRow(
    val id: String,
    @SerialName("parent_id") val parentId: String? = null,
    @SerialName("name_ar") val nameAr: String,
    @SerialName("slug") val slug: String,
    @SerialName("description_ar") val descriptionAr: String? = null,
    @SerialName("image_url") val imageUrl: String? = null,
    @SerialName("display_order") val displayOrder: Int = 0,
    @SerialName("is_active") val isActive: Boolean = true
)

@Serializable
private data class ProductRow(
    val id: String,
    @SerialName("category_id") val categoryId: String?,
    @SerialName("name_ar") val nameAr: String,
    val slug: String,
    val sku: String? = null,
    @SerialName("description_ar") val descriptionAr: String? = null,
    val price: Double = 0.0,
    @SerialName("compare_at_price") val compareAtPrice: Double? = null,
    val featured: Boolean = false,
    @SerialName("track_inventory") val trackInventory: Boolean = true,
    val status: String = "draft"
)

@Serializable
private data class ImageRow(
    val id: String,
    @SerialName("product_id") val productId: String,
    @SerialName("storage_path") val storagePath: String,
    @SerialName("image_url") val imageUrl: String? = null,
    @SerialName("display_order") val displayOrder: Int = 0,
    @SerialName("is_primary") val isPrimary: Boolean = false
)

@Serializable
private data class VariantRow(
    val id: String,
    @SerialName("product_id") val productId: String,
    val options: JsonObject = JsonObject(emptyMap()),
    @SerialName("price_override") val priceOverride: Double? = null,
    @SerialName("stock_quantity") val stockQuantity: Int = 0,
    @SerialName("reserved_quantity") val reservedQuantity: Int = 0,
    @SerialName("is_active") val isActive: Boolean = true
)

class SupabaseCatalogRepository(
    private val fallback: CatalogRepository = LocalCatalogRepository()
) : CatalogRepository {
    private val categories = MutableStateFlow<List<Category>>(emptyList())
    private val products = MutableStateFlow<List<Product>>(emptyList())

    override fun observeCategories(): Flow<List<Category>> = categories
    override fun observeProducts(): Flow<List<Product>> = products

    override suspend fun refresh() = withContext(Dispatchers.IO) {
        runCatching {
            val client = SupabaseClientProvider.client
            val categoryRows = client.from("categories").select().decodeList<CategoryRow>()
            val productRows = client.from("products").select().decodeList<ProductRow>()
            val imageRows = client.from("product_images").select().decodeList<ImageRow>()
            val variantRows = client.from("product_variants").select().decodeList<VariantRow>()

            val imageByProduct = imageRows
                .groupBy { it.productId }
                .mapValues { (_, images) ->
                    images.sortedWith(compareByDescending<ImageRow> { it.isPrimary }.thenBy { it.displayOrder })
                }

            val variantsByProduct = variantRows
                .filter { it.isActive }
                .groupBy { it.productId }

            categories.value = categoryRows
                .filter { it.isActive }
                .sortedBy { it.displayOrder }
                .map { row ->
                    Category(
                        id = row.id,
                        name = row.nameAr,
                        description = row.descriptionAr.orEmpty(),
                        iconKey = row.slug.ifBlank { "category" },
                        sortOrder = row.displayOrder,
                        isActive = row.isActive,
                        parentId = row.parentId
                    )
                }

            products.value = productRows
                .filter { it.status == "active" }
                .map { row ->
                    val variants = variantsByProduct[row.id].orEmpty()
                    val availableStock = if (!row.trackInventory) {
                        Int.MAX_VALUE
                    } else {
                        variants.sumOf { (it.stockQuantity - it.reservedQuantity).coerceAtLeast(0) }
                    }
                    val image = imageByProduct[row.id].orEmpty().firstOrNull()?.let {
                        it.imageUrl?.takeIf(String::isNotBlank)
                            ?: it.storagePath.takeIf(String::isNotBlank)?.let { path ->
                                client.storage.from("product-images").publicUrl(path)
                            }
                    }
                    val colors = variants.mapNotNull {
                        (it.options["color"] as? JsonPrimitive).asStringOrNull()
                            ?: (it.options["colour"] as? JsonPrimitive).asStringOrNull()
                            ?: (it.options["اللون"] as? JsonPrimitive).asStringOrNull()
                    }.distinct()
                    val sizes = variants.mapNotNull {
                        (it.options["size"] as? JsonPrimitive).asStringOrNull()
                            ?: (it.options["مقاس"] as? JsonPrimitive).asStringOrNull()
                            ?: (it.options["المقاس"] as? JsonPrimitive).asStringOrNull()
                    }.distinct()
                    Product(
                        id = row.id,
                        categoryId = row.categoryId.orEmpty(),
                        name = row.nameAr,
                        price = row.price.toInt(),
                        oldPrice = row.compareAtPrice?.toInt(),
                        description = row.descriptionAr.orEmpty(),
                        imageUrl = image,
                        stock = availableStock,
                        isActive = row.status == "active",
                        colors = colors,
                        sizes = sizes,
                        sku = row.sku
                    )
                }
        }.onFailure {
            val local = LocalCatalogSnapshot(fallback)
            local.refresh()
            categories.value = local.categories
            products.value = local.products
        }
    }
}

private fun JsonPrimitive?.asStringOrNull(): String? = this?.contentOrNull

private class LocalCatalogSnapshot(private val source: CatalogRepository) {
    var categories: List<Category> = emptyList()
    var products: List<Product> = emptyList()

    suspend fun refresh() {
        source.refresh()
        source.observeCategories().first().let { categories = it }
        source.observeProducts().first().let { products = it }
    }
}
