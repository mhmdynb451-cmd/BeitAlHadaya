package com.beitalhadaya.app.data

import com.beitalhadaya.app.BuildConfig

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage

/**
 * Client-side Supabase configuration.
 *
 * The publishable key is designed for public/mobile clients.
 * Never place a Supabase secret or service_role key in this class or the APK.
 */
object SupabaseClientProvider {
    private const val SUPABASE_URL = BuildConfig.SUPABASE_URL
    private const val SUPABASE_PUBLISHABLE_KEY = BuildConfig.SUPABASE_PUBLISHABLE_KEY

    val client: SupabaseClient = createSupabaseClient(
        supabaseUrl = SUPABASE_URL,
        supabaseKey = SUPABASE_PUBLISHABLE_KEY
    ) {
        install(Postgrest)
        install(Storage)
    }
}
