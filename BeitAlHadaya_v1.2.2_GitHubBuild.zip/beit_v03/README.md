# بيت الهدايا غاوي خسارة — V1.2.2

نسخة تأسيسية للتطبيق العربي RTL باستخدام Kotlin + Jetpack Compose + Material 3، بهوية Premium (داكن + نبيتي + كريمي + ذهبي)، مع بنية بيانات ديناميكية، سلة، checkout، طلبات، إشعارات، مفضلة، وإطار اختياري للبوتات الذكية.

## البناء
- Android API 36 compile/target.
- Java 17.
- AGP 8.13.2 + Gradle 8.13.
- Kotlin 2.3.21.
- Compose BOM 2026.08.00.

## مهم
الدفع الإلكتروني والذكاء الاصطناعي الفعلي لا يوضعان بمفاتيحهما داخل APK؛ يتم ربطهما لاحقًا بخادم HTTPS آمن.


## Supabase integration
- Public catalog and store settings now load from Supabase.
- The Android client uses only the Supabase publishable key; no service-role/secret key is included.
- Supabase URL/key can be overridden at build time with `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY`.
- Categories, products, product images, variants, and store payment flags are mapped through repository adapters.
- Local repositories remain as a safe offline fallback for catalog/settings when the backend is unavailable.
- Real authentication, persistent customer orders, and real payment-gateway processing remain separate server-backed phases.
