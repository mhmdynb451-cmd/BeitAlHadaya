# بيت الهدايا غاوي خسارة — Supabase Integration V1.2.2

## Implemented
- Supabase client using the publishable key only.
- PostgREST catalog adapter for categories/products.
- Product image URL mapping through the `product-images` public bucket.
- Product variants mapped for stock, colors, and sizes.
- Store settings adapter for shipping, COD, Visa, and Vodafone Cash flags.
- Local catalog/settings fallback when Supabase is unavailable.
- Android minimum SDK raised to 26 to match the current supabase-kt Android baseline.
- Target/compile SDK remains 36.
- Version bumped to 1.2.2 / versionCode 6.
- Active GitHub Actions workflow included for Java 17 + Gradle 8.13 + Android 36.

## Backend verification
- Supabase project is healthy and accessible.
- 10 active categories exist.
- 0 products are stored intentionally at this stage.
- COD is enabled with a 100 EGP commitment fee.
- Visa and Vodafone Cash flags are enabled.
- `public.checkout` and `private.checkout` functions exist.
- `product-images` storage bucket exists.
- Security advisor returned zero security lints during this integration pass.

## Intentionally not included yet
- Real user authentication/session flow.
- Persistent customer orders wired from the Android UI to `public.checkout`.
- Real Visa/Vodafone Cash gateway processing.
- AI/bot secrets or service-role/secret keys in the APK.

## GitHub status
The connected GitHub integration currently rejects write operations with HTTP 403 (`Resource not accessible by integration`). This package is therefore prepared locally and has not been pushed by the assistant.
