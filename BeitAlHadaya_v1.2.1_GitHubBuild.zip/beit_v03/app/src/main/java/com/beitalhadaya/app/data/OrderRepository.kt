package com.beitalhadaya.app.data

import kotlinx.coroutines.flow.Flow

interface OrderRepository {
    fun observeOrders(): Flow<List<Order>>
    suspend fun save(order: Order)
}
