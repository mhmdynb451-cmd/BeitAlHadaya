package com.beitalhadaya.app.data

enum class PaymentMethod {
    CARD,
    VODAFONE_CASH,
    CASH_ON_DELIVERY
}

enum class OrderStatus {
    PAYMENT_PENDING,
    CONFIRMED,
    PREPARING,
    SHIPPED,
    OUT_FOR_DELIVERY,
    DELIVERED,
    CANCELLED
}

data class Category(
    val id: String,
    val name: String,
    val description: String,
    val iconKey: String,
    val sortOrder: Int,
    val isActive: Boolean = true,
    val parentId: String? = null
)

data class Product(
    val id: String,
    val categoryId: String,
    val name: String,
    val price: Int,
    val oldPrice: Int? = null,
    val description: String = "",
    val imageUrl: String? = null,
    val stock: Int = 0,
    val isActive: Boolean = true,
    val colors: List<String> = emptyList(),
    val sizes: List<String> = emptyList(),
    val sku: String? = null
)

data class CartItem(
    val product: Product,
    val quantity: Int
) {
    val lineTotal: Int get() = product.price * quantity
}

data class DeliveryAddress(
    val fullName: String,
    val phone: String,
    val governorate: String,
    val city: String,
    val details: String
)

data class Order(
    val id: String,
    val items: List<CartItem>,
    val subtotal: Int,
    val shipping: Int,
    val codDeposit: Int,
    val totalDueNow: Int,
    val amountDueOnDelivery: Int,
    val paymentMethod: PaymentMethod,
    val status: OrderStatus,
    val address: DeliveryAddress,
    val createdAtEpochMs: Long
)


enum class BotStatus { ENABLED, DISABLED }

enum class BotPermission {
    READ_PRODUCTS,
    READ_PRICES,
    READ_STOCK,
    READ_ORDERS,
    ANSWER_CUSTOMERS,
    UPDATE_PRODUCTS,
    CREATE_PROMOTIONS
}

data class BotIntegration(
    val id: String,
    val name: String,
    val task: String,
    val description: String,
    val aiProvider: String? = null,
    val endpoint: String? = null,
    val permissions: Set<BotPermission> = emptySet(),
    val status: BotStatus = BotStatus.DISABLED,
    val settingsJson: String = "{}"
)

data class StoreSettings(
    val shippingFee: Int = 70,
    val codDeposit: Int = 100,
    val currency: String = "ج.م",
    val guestCheckoutEnabled: Boolean = true,
    val notificationsEnabled: Boolean = true
)


data class ProductVariant(
    val id: String,
    val productId: String,
    val sku: String?,
    val size: String?,
    val color: String?,
    val priceDelta: Int = 0,
    val stock: Int = 0,
    val isActive: Boolean = true
)

data class Coupon(
    val code: String,
    val discountPercent: Int? = null,
    val discountAmount: Int? = null,
    val minimumOrderAmount: Int = 0,
    val isActive: Boolean = true
)

data class NotificationItem(
    val id: String,
    val title: String,
    val body: String,
    val createdAtEpochMs: Long,
    val isRead: Boolean = false
)

data class ShippingOption(
    val id: String,
    val name: String,
    val fee: Int,
    val estimatedDaysText: String,
    val isActive: Boolean = true
)

enum class AdminRole { OWNER, MANAGER, EDITOR, SUPPORT }

data class AdminUser(
    val id: String,
    val name: String,
    val role: AdminRole,
    val isActive: Boolean = true
)
