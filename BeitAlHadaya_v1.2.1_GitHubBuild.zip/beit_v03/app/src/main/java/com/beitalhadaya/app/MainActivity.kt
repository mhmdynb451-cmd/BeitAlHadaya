package com.beitalhadaya.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.beitalhadaya.app.data.CartItem
import com.beitalhadaya.app.data.Category
import com.beitalhadaya.app.data.Order
import com.beitalhadaya.app.data.OrderStatus
import com.beitalhadaya.app.data.PaymentMethod
import com.beitalhadaya.app.data.Product
import com.beitalhadaya.app.ui.Screen
import com.beitalhadaya.app.ui.StoreUiState
import com.beitalhadaya.app.ui.StoreViewModel
import com.beitalhadaya.app.ui.theme.BeitAlHadayaTheme

private const val PREFS = "beit_al_hadaya_prefs"
private const val KEY_ONBOARDING_DONE = "onboarding_done"

class MainActivity : ComponentActivity() {
    private val storeViewModel: StoreViewModel by viewModels {
        StoreViewModel.Factory(com.beitalhadaya.app.data.LocalCatalogRepository())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val done = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ONBOARDING_DONE, false)
        setContent {
            BeitAlHadayaTheme {
                StoreApp(storeViewModel, initiallyOnboarded = done) {
                    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ONBOARDING_DONE, true).apply()
                }
            }
        }
    }
}

@Composable
private fun StoreApp(viewModel: StoreViewModel, initiallyOnboarded: Boolean, onOnboardingDone: () -> Unit) {
    val state by viewModel.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var onboarded by remember { mutableStateOf(initiallyOnboarded) }
    var onboardingStage by remember { mutableStateOf(0) }

    LaunchedEffect(state.infoMessage) {
        state.infoMessage?.let { snackbar.showSnackbar(it); viewModel.clearMessage() }
    }

    if (!onboarded) {
        when (onboardingStage) {
            0 -> WelcomeScreen(onNext = { onboardingStage = 1 })
            else -> TermsScreen(
                onAccepted = {
                    onboarded = true
                    onOnboardingDone()
                }
            )
        }
        return
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (state.screen == Screen.Home || state.screen == Screen.Cart || state.screen == Screen.Orders || state.screen == Screen.Account) {
                BottomNavigation(state, viewModel)
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (val screen = state.screen) {
                Screen.Home -> HomeScreen(state, viewModel)
                Screen.Notifications -> NotificationsScreen(state, viewModel)
                Screen.Wishlist -> WishlistScreen(state, viewModel)
                is Screen.Category -> CategoryScreen(state, viewModel, screen.categoryId)
                is Screen.Product -> ProductScreen(state, viewModel, screen.productId)
                Screen.Cart -> CartScreen(state, viewModel)
                Screen.Checkout -> CheckoutScreen(state, viewModel)
                Screen.Orders -> OrdersScreen(state, viewModel)
                Screen.Account -> AccountScreen(state, viewModel)
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onNext: () -> Unit) {
    val bg = Brush.verticalGradient(listOf(Color(0xFF0D1014), Color(0xFF171B20)))
    Box(Modifier.fillMaxSize().background(bg).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Box(Modifier.size(104.dp).background(Color(0xFF1F252C), RoundedCornerShape(32.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.CardGiftcard, null, tint = Color(0xFFE2BE7A), modifier = Modifier.size(58.dp))
            }
            Text("بيت الهدايا", color = Color(0xFFF7F0E5), fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("غاوي خسارة", color = Color(0xFFE0B86E), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text("كل ما تحتاجه في مكان واحد", color = Color(0xFFD8D0C7), fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onNext,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7E1830), contentColor = Color.White)
            ) { Text("ابدأ الآن", fontWeight = FontWeight.Bold) }
            TextButton(onClick = onNext) { Text("متابعة لاحقًا", color = Color(0xFFE7D4AE)) }
        }
    }
}

@Composable
private fun TermsScreen(onAccepted: () -> Unit) {
    var acceptedTerms by remember { mutableStateOf(false) }
    var acceptedPrivacy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp)) {
        Spacer(Modifier.height(22.dp))
        Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(46.dp))
        Spacer(Modifier.height(12.dp))
        Text("قبل الدخول للتطبيق", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("نريد أن تكون تجربة التسوق واضحة وآمنة من البداية.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(22.dp))
        AgreementRow(acceptedTerms, { acceptedTerms = !acceptedTerms }, "أوافق على الشروط والأحكام")
        AgreementRow(acceptedPrivacy, { acceptedPrivacy = !acceptedPrivacy }, "أوافق على سياسة الخصوصية")
        Card(
            Modifier.fillMaxWidth().padding(top = 18.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.secondary)
                Text("لن نطلب منك صلاحيات غير ضرورية. بيانات الدفع ومفاتيح الخدمات السرية لن توضع داخل التطبيق.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onAccepted,
            enabled = acceptedTerms && acceptedPrivacy,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(18.dp)
        ) { Text("متابعة إلى المتجر") }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun AgreementRow(checked: Boolean, onClick: () -> Unit, text: String) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(checked = checked, onCheckedChange = { onClick() })
            Text(text, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun BottomNavigation(state: StoreUiState, viewModel: StoreViewModel) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp, modifier = Modifier.navigationBarsPadding()) {
        val selected = when (state.screen) {
            Screen.Home -> 0
            Screen.Cart -> 1
            Screen.Orders -> 2
            Screen.Account -> 3
            else -> 0
        }
        NavigationBarItem(selected = selected == 0, onClick = viewModel::goHome, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
        NavigationBarItem(selected = selected == 1, onClick = viewModel::openCart, icon = {
            BadgedBox(badge = { if (state.cartCount > 0) Badge { Text(state.cartCount.toString()) } }) { Icon(Icons.Default.ShoppingCart, null) }
        }, label = { Text("السلة") })
        NavigationBarItem(selected = selected == 2, onClick = viewModel::openOrders, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("طلباتي") })
        NavigationBarItem(selected = selected == 3, onClick = viewModel::openAccount, icon = { Icon(Icons.Default.AccountCircle, null) }, label = { Text("حسابي") })
    }
}

@Composable
private fun HomeScreen(state: StoreUiState, viewModel: StoreViewModel) {
    val categories = state.categories.sortedBy { it.sortOrder }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(50.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.CardGiftcard, null, tint = Color.White)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("بيت الهدايا", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("غاوي خسارة", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                }
                IconButton(onClick = viewModel::openNotifications) { Icon(Icons.Default.NotificationsNone, "الإشعارات") }
                IconButton(onClick = viewModel::openCart) {
                    BadgedBox(badge = { if (state.cartCount > 0) Badge { Text(state.cartCount.toString()) } }) { Icon(Icons.Default.ShoppingCart, "السلة") }
                }
            }
        }
        item {
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = viewModel::updateSearch,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = { if (state.searchQuery.isNotBlank()) IconButton(onClick = { viewModel.updateSearch("") }) { Icon(Icons.Default.Close, null) } },
                placeholder = { Text("ابحث عن منتج أو قسم …") }
            )
        }
        item { HeroBanner() }
        item { SectionHeader("الأقسام", "تصفح كل الأقسام") }
        item {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 108.dp),
                modifier = Modifier.fillMaxWidth().height(300.dp),
                userScrollEnabled = false,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                gridItems(categories) { category -> CategoryCard(category) { viewModel.openCategory(category.id) } }
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("عروض خاصة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("خصومات ومناسبات مميزة ستظهر من لوحة الإدارة", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                    }
                    Icon(Icons.Default.Campaign, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(36.dp))
                }
            }
        }
        item { SectionHeader("المنتجات", if (state.products.isEmpty()) "في انتظار منتجات لوحة الإدارة" else "مختارات المتجر") }
        if (state.products.isEmpty()) {
            item { EmptyState("المتجر جاهز لإضافة المنتجات", "لن نضع منتجات وهمية داخل التطبيق. عند إضافة المنتجات من الإدارة ستظهر هنا بنفس التصميم المعتمد.", Icons.Default.ShoppingBag) }
        } else {
            lazyItems(state.products.take(6), key = { it.id }) { ProductCard(it, state.favoriteIds.contains(it.id), viewModel::toggleFavorite) { viewModel.openProduct(it.id) } }
        }
    }
}

@Composable
private fun HeroBanner() {
    Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
        Box(Modifier.fillMaxWidth().height(188.dp).background(Brush.horizontalGradient(listOf(Color(0xFF171A1F), Color(0xFF7E1830))), RoundedCornerShape(26.dp)).padding(20.dp)) {
            Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.7f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("أجمل الهدايا لأحبائك", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("تجربة تسوق أنيقة، واضحة، وآمنة.", color = Color.White.copy(alpha = 0.88f))
                AssistChip(onClick = {}, label = { Text("تسوق الآن") })
            }
            Icon(Icons.Default.CardGiftcard, null, tint = Color(0xFFE7D4AE), modifier = Modifier.size(84.dp).align(Alignment.BottomEnd))
        }
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CategoryCard(category: Category, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.size(54.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape), contentAlignment = Alignment.Center) {
                Icon(iconFor(category.iconKey), null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            }
            Text(category.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, textAlign = TextAlign.Center)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CategoryScreen(state: StoreUiState, viewModel: StoreViewModel, categoryId: String) {
    val category = state.categories.firstOrNull { it.id == categoryId }
    val products = state.products.filter { it.categoryId == categoryId && it.isActive }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(category?.name ?: "القسم") },
            navigationIcon = { IconButton(onClick = viewModel::goHome) { Icon(Icons.Default.ArrowBack, "رجوع") } },
            actions = { IconButton(onClick = viewModel::openCart) { Icon(Icons.Default.ShoppingCart, "السلة") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
    }) { padding ->
        if (products.isEmpty()) EmptyState("لا توجد منتجات في هذا القسم الآن", "القسم جاهز، والمنتجات ستصل لاحقًا من طبقة الإدارة أو خدمة الكتالوج.", iconFor(category?.iconKey ?: "category"), Modifier.fillMaxSize().padding(padding).padding(24.dp))
        else LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 155.dp), modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            gridItems(products, key = { it.id }) { product -> ProductCard(product, state.favoriteIds.contains(product.id), viewModel::toggleFavorite) { viewModel.openProduct(product.id) } }
        }
    }
}

@Composable
private fun ProductCard(product: Product, favorite: Boolean, onFavorite: (String) -> Unit, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(10.dp)) {
            Box(Modifier.fillMaxWidth().height(150.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.ShoppingBag, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
                IconButton(onClick = { onFavorite(product.id) }, modifier = Modifier.align(Alignment.TopEnd)) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "المفضلة", tint = MaterialTheme.colorScheme.primary) }
            }
            Spacer(Modifier.height(8.dp))
            Text(product.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${product.price} ج.م", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (product.oldPrice != null) Text("${product.oldPrice} ج.م", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductScreen(state: StoreUiState, viewModel: StoreViewModel, productId: String) {
    val product = state.products.firstOrNull { it.id == productId }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("تفاصيل المنتج") },
            navigationIcon = { IconButton(onClick = viewModel::back) { Icon(Icons.Default.ArrowBack, "رجوع") } },
            actions = {
                if (product != null) IconButton(onClick = { viewModel.toggleFavorite(product.id) }) { Icon(if (state.favoriteIds.contains(product.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "المفضلة") }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
        )
    }) { padding ->
        if (product == null) EmptyState("المنتج غير موجود", "قد يكون المنتج غير متاح حاليًا أو لم تتم إضافته من الإدارة بعد.", Icons.Default.Info, Modifier.fillMaxSize().padding(padding))
        else LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            item { Box(Modifier.fillMaxWidth().height(290.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.ShoppingBag, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(100.dp)) } }
            item { Text(product.name, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Text("${product.price} ج.م", fontSize = 22.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold); Spacer(Modifier.width(10.dp)); product.oldPrice?.let { Text("${it} ج.م", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
            item { Text(product.description.ifBlank { "وصف المنتج سيُدار من لوحة الإدارة." }, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 22.sp) }
            if (product.sizes.isNotEmpty()) item { ChoiceRow("المقاسات", product.sizes) }
            if (product.colors.isNotEmpty()) item { ChoiceRow("الألوان", product.colors) }
            item {
                Button(onClick = { viewModel.addToCart(product) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp)) {
                    Icon(Icons.Default.ShoppingCart, null); Spacer(Modifier.width(8.dp)); Text("أضف إلى السلة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ChoiceRow(title: String, choices: List<String>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { choices.take(5).forEach { AssistChip(onClick = {}, label = { Text(it) }) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CartScreen(state: StoreUiState, viewModel: StoreViewModel) {
    Scaffold(topBar = { TopAppBar(title = { Text("السلة (${state.cartCount})") }, navigationIcon = { IconButton(onClick = viewModel::goHome) { Icon(Icons.Default.ArrowBack, "رجوع") } }) }) { padding ->
        if (state.cart.isEmpty()) EmptyState("السلة فارغة", "أضف المنتجات التي تريدها وستظهر تفاصيل السعر والشحن هنا.", Icons.Default.ShoppingCart, Modifier.fillMaxSize().padding(padding).padding(24.dp))
        else LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp)) {
            lazyItems(state.cart, key = { it.product.id }) { item -> CartRow(item, viewModel) }
            item {
                DividerSummary("إجمالي المنتجات", "${state.cartSubtotal} ج.م")
                DividerSummary("الشحن", "${state.settings.shippingFee} ج.م")
                DividerSummary("الإجمالي", "${state.cartSubtotal + state.settings.shippingFee} ج.م", emphasize = true)
                Spacer(Modifier.height(10.dp))
                Button(onClick = viewModel::startCheckout, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) { Text("إتمام الطلب") }
            }
        }
    }
}

@Composable
private fun CartRow(item: CartItem, viewModel: StoreViewModel) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(68.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.ShoppingBag, null, tint = MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(item.product.name, fontWeight = FontWeight.Bold)
                Text("${item.lineTotal} ج.م", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.decrease(item) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Remove, null) }
                    Text(item.quantity.toString(), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { viewModel.increase(item) }, modifier = Modifier.size(32.dp)) { Text("+") }
                }
            }
            IconButton(onClick = { viewModel.removeFromCart(item.product.id) }) { Icon(Icons.Default.DeleteOutline, "حذف") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CheckoutScreen(state: StoreUiState, viewModel: StoreViewModel) {
    Scaffold(topBar = { TopAppBar(title = { Text("إتمام الطلب") }, navigationIcon = { IconButton(onClick = viewModel::openCart) { Icon(Icons.Default.ArrowBack, "رجوع") } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp).imePadding(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            item { StepHeader() }
            item { Text("عنوان التوصيل", fontSize = 19.sp, fontWeight = FontWeight.Bold) }
            item { AddressFields(state, viewModel) }
            item { Text("طريقة الدفع", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
            item { PaymentChoice("Visa / Mastercard", PaymentMethod.CARD, state, viewModel, Icons.Default.CreditCard) }
            item { PaymentChoice("Vodafone Cash", PaymentMethod.VODAFONE_CASH, state, viewModel, Icons.Default.Payments) }
            item { PaymentChoice("الدفع عند الاستلام", PaymentMethod.CASH_ON_DELIVERY, state, viewModel, Icons.Default.LocalShipping, "مقدم تأكيد ${state.settings.codDeposit} ج.م") }
            item { DividerSummary("المنتجات", "${state.cartSubtotal} ج.م") }
            item { DividerSummary("الشحن", "${state.settings.shippingFee} ج.م") }
            if (state.selectedPaymentMethod == PaymentMethod.CASH_ON_DELIVERY) item { DividerSummary("المطلوب الآن", "${state.settings.codDeposit} ج.م", emphasize = true) }
            item { Button(onClick = viewModel::confirmOrder, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) { Text("تأكيد الطلب") } }
            item { Text("الدفع الإلكتروني سيعمل بعد ربط بوابة الدفع بالخادم الآمن.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun StepHeader() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        listOf("العنوان", "الدفع", "التأكيد").forEachIndexed { index, title ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(34.dp).background(if (index == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, CircleShape), contentAlignment = Alignment.Center) { Text("${index + 1}", color = if (index == 0) Color.White else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold) }
                Text(title, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun AddressFields(state: StoreUiState, viewModel: StoreViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        OutlinedTextField(state.address.fullName, { viewModel.updateAddress(fullName = it) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الاسم الكامل") }, leadingIcon = { Icon(Icons.Default.Person, null) })
        OutlinedTextField(state.address.phone, { viewModel.updateAddress(phone = it) }, Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), label = { Text("رقم الهاتف") }, leadingIcon = { Icon(Icons.Default.Phone, null) })
        OutlinedTextField(state.address.governorate, { viewModel.updateAddress(governorate = it) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("المحافظة") }, leadingIcon = { Icon(Icons.Default.LocationOn, null) })
        OutlinedTextField(state.address.city, { viewModel.updateAddress(city = it) }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("المدينة") })
        OutlinedTextField(state.address.details, { viewModel.updateAddress(details = it) }, Modifier.fillMaxWidth(), minLines = 2, label = { Text("العنوان بالتفصيل") })
    }
}

@Composable
private fun PaymentChoice(title: String, method: PaymentMethod, state: StoreUiState, viewModel: StoreViewModel, icon: ImageVector, subtitle: String? = null) {
    Card(Modifier.fillMaxWidth().clickable { viewModel.selectPaymentMethod(method) }, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, if (state.selectedPaymentMethod == method) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = state.selectedPaymentMethod == method, onClick = { viewModel.selectPaymentMethod(method) })
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                subtitle?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

@Composable
private fun OrdersScreen(state: StoreUiState, viewModel: StoreViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("طلباتي", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        if (state.orders.isEmpty()) EmptyState("لا توجد طلبات حتى الآن", "بعد أول عملية شراء ستظهر الطلبات وحالتها هنا.", Icons.Default.ReceiptLong, Modifier.fillMaxSize())
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { lazyItems(state.orders.reversed(), key = { it.id }) { OrderCard(it) } }
    }
}

@Composable
private fun OrderCard(order: Order) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("طلب ${order.id}", fontWeight = FontWeight.Bold); Text("${order.items.size} منتج", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; StatusChip(order.status) }
            HorizontalDivider()
            Text("إجمالي الطلب: ${order.totalDueNow + order.amountDueOnDelivery} ج.م", fontWeight = FontWeight.Bold)
            if (order.paymentMethod == PaymentMethod.CASH_ON_DELIVERY) Text("مقدم التأكيد: ${order.totalDueNow} ج.م • المتبقي عند الاستلام: ${order.amountDueOnDelivery} ج.م", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OrderTimeline(order.status)
        }
    }
}

@Composable
private fun StatusChip(status: OrderStatus) {
    val text = when (status) { OrderStatus.PAYMENT_PENDING -> "في انتظار الدفع"; OrderStatus.CONFIRMED -> "تم الاستلام"; OrderStatus.PREPARING -> "جاري التجهيز"; OrderStatus.SHIPPED -> "تم الشحن"; OrderStatus.OUT_FOR_DELIVERY -> "خرج للتوصيل"; OrderStatus.DELIVERED -> "تم التسليم"; OrderStatus.CANCELLED -> "ملغي" }
    AssistChip(onClick = {}, label = { Text(text) })
}

@Composable
private fun OrderTimeline(status: OrderStatus) {
    val index = when (status) { OrderStatus.PAYMENT_PENDING -> 0; OrderStatus.CONFIRMED -> 1; OrderStatus.PREPARING -> 2; OrderStatus.SHIPPED -> 3; OrderStatus.OUT_FOR_DELIVERY -> 4; OrderStatus.DELIVERED -> 5; OrderStatus.CANCELLED -> -1 }
    if (index < 0) return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        val labels = listOf("استلام", "تجهيز", "شحن", "توصيل", "تسليم")
        labels.forEachIndexed { i, label ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(12.dp).background(if (i <= index.coerceAtMost(4)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, CircleShape))
                Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun NotificationsScreen(state: StoreUiState, viewModel: StoreViewModel) {
    TopSection("الإشعارات", viewModel::back, Icons.Default.NotificationsNone)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)) {
        if (state.orders.isEmpty()) item { EmptyState("لا توجد إشعارات بعد", "ستظهر إشعارات الطلبات والعروض الجديدة هنا.", Icons.Default.NotificationsNone) }
        else lazyItems(state.orders.reversed()) { order -> NotificationRow("تم تأكيد طلبك ${order.id}", "يمكنك متابعة حالته من قسم طلباتي", Icons.Default.ReceiptLong) }
    }
}

@Composable
private fun NotificationRow(title: String, subtitle: String, icon: ImageVector) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(44.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape), contentAlignment = Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }; Spacer(Modifier.width(10.dp)); Column { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
}

@Composable
private fun WishlistScreen(state: StoreUiState, viewModel: StoreViewModel) {
    TopSection("المفضلة", viewModel::back, Icons.Default.Favorite)
    val products = state.products.filter { it.id in state.favoriteIds }
    if (products.isEmpty()) EmptyState("المفضلة فارغة", "اضغط على القلب داخل أي منتج لإضافته إلى المفضلة.", Icons.Default.FavoriteBorder, Modifier.fillMaxSize().padding(24.dp))
    else LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 155.dp), modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { gridItems(products) { ProductCard(it, true, viewModel::toggleFavorite) { viewModel.openProduct(it.id) } } }
}

@Composable
private fun AccountScreen(state: StoreUiState, viewModel: StoreViewModel) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { Text("حسابي", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item { ProfileHeader() }
        item { AccountRow("طلباتي", "${state.orders.size} طلب", Icons.Default.ReceiptLong) { viewModel.openOrders() } }
        item { AccountRow("المفضلة", "${state.favoriteIds.size} منتج", Icons.Default.Favorite) { viewModel.openWishlist() } }
        item { AccountRow("الإشعارات", "محدثة تلقائيًا", Icons.Default.NotificationsNone) { viewModel.openNotifications() } }
        item { AccountRow("العناوين", "يتم حفظها أثناء إتمام الطلب", Icons.Default.LocationOn) { } }
        item { AccountRow("الدعم والمساعدة", "قناة دعم مستقلة لاحقًا", Icons.Default.Person) { } }
        item { AccountRow("الإعدادات", "الخصوصية والتنبيهات", Icons.Default.Settings) { } }
        item {
            OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp)) { Text("تسجيل الدخول / إنشاء حساب") }
        }
    }
}

@Composable
private fun ProfileHeader() {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).background(Color.White.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
            Spacer(Modifier.width(12.dp))
            Column { Text("ضيف المتجر", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("التصفح والشراء ممكنان بدون إجبار على حساب", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp) }
        }
    }
}

@Composable
private fun AccountRow(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape), contentAlignment = Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Icon(Icons.Default.ChevronLeft, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ProfileStatusDialog(onClose: () -> Unit) {
    AlertDialog(onDismissRequest = onClose, confirmButton = { TextButton(onClick = onClose) { Text("إغلاق") } }, title = { Text("الحساب") }, text = { Text("سيتم تفعيل المصادقة الحقيقية بعد ربط الخادم الآمن.") })
}

@Composable
private fun TopSection(title: String, onBack: () -> Unit, icon: ImageVector) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع") }
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DividerSummary(label: String, value: String, emphasize: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontWeight = if (emphasize) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontWeight = if (emphasize) FontWeight.Bold else FontWeight.Medium, color = if (emphasize) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun EmptyState(title: String, message: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(82.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape), contentAlignment = Alignment.Center) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp)) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, fontSize = 13.sp)
    }
}

private fun iconFor(key: String): ImageVector = when (key) {
    "women" -> Icons.Default.ShoppingBag
    "men" -> Icons.Default.Person
    "kids" -> Icons.Default.Person
    "shoes" -> Icons.Default.ShoppingBag
    "school" -> Icons.Default.Category
    "accessories" -> Icons.Default.Favorite
    "gifts" -> Icons.Default.CardGiftcard
    "home" -> Icons.Default.Home
    "beauty" -> Icons.Default.VerifiedUser
    "appliances" -> Icons.Default.Settings
    else -> Icons.Default.Category
}
