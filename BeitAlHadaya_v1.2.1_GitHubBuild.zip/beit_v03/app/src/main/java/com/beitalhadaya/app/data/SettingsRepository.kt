package com.beitalhadaya.app.data

import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    fun observeSettings(): Flow<StoreSettings>
    suspend fun updateSettings(settings: StoreSettings)
}
