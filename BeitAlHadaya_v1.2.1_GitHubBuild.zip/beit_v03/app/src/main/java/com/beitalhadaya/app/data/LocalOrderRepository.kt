package com.beitalhadaya.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

class LocalOrderRepository : OrderRepository {
    private val orders = MutableStateFlow<List<Order>>(emptyList())

    override fun observeOrders(): Flow<List<Order>> = orders

    override suspend fun save(order: Order) {
        orders.value = listOf(order) + orders.value
    }
}
