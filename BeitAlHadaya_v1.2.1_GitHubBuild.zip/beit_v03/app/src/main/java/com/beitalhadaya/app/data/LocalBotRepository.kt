package com.beitalhadaya.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

class LocalBotRepository : BotRepository {
    private val bots = MutableStateFlow<List<BotIntegration>>(emptyList())
    override fun observeBots(): Flow<List<BotIntegration>> = bots
    override suspend fun saveBot(bot: BotIntegration) { bots.update { current -> current.filterNot { it.id == bot.id } + bot } }
    override suspend fun setBotStatus(botId: String, status: BotStatus) { bots.update { current -> current.map { if (it.id == botId) it.copy(status = status) else it } } }
    override suspend fun removeBot(botId: String) { bots.update { current -> current.filterNot { it.id == botId } } }
}
