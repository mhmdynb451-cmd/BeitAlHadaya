package com.beitalhadaya.app.data

/**
 * Boundary contracts for the future secure backend. No payment keys or AI secrets belong in the APK.
 */
interface AuthService
interface ProductCatalogService
interface OrderService
interface PaymentGateway {
    suspend fun createPaymentRequest(order: Order): Result<String>
}
interface AiBotService {
    suspend fun respond(bot: BotIntegration, userMessage: String): Result<String>
}
