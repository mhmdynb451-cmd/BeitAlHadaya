package com.beitalhadaya.app.data

import kotlinx.coroutines.flow.Flow

interface BotRepository {
    fun observeBots(): Flow<List<BotIntegration>>
    suspend fun saveBot(bot: BotIntegration)
    suspend fun setBotStatus(botId: String, status: BotStatus)
    suspend fun removeBot(botId: String)
}
