package com.beitalhadaya.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Approved visual identity: near-black/navy + burgundy + cream + muted gold.
private val Ink = Color(0xFF111317)
private val InkSoft = Color(0xFF1B2027)
private val Burgundy = Color(0xFF7E1830)
private val BurgundyDark = Color(0xFF5F1024)
private val Cream = Color(0xFFF7F0E5)
private val CreamSoft = Color(0xFFFCF8F1)
private val Gold = Color(0xFFC8A15A)
private val GoldSoft = Color(0xFFE7D4AE)
private val TextDark = Color(0xFF24211D)
private val TextMuted = Color(0xFF746C62)

private val LightColors = lightColorScheme(
    primary = Burgundy,
    onPrimary = Color.White,
    primaryContainer = BurgundyDark,
    onPrimaryContainer = Color.White,
    secondary = Gold,
    onSecondary = TextDark,
    secondaryContainer = GoldSoft,
    onSecondaryContainer = TextDark,
    tertiary = Ink,
    onTertiary = Color.White,
    background = Cream,
    onBackground = TextDark,
    surface = CreamSoft,
    onSurface = TextDark,
    surfaceVariant = Color(0xFFEDE4D7),
    onSurfaceVariant = TextMuted,
    outline = Color(0xFFD4C9BB),
    error = Color(0xFFB3261E),
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFC63B5B),
    onPrimary = Color.White,
    primaryContainer = BurgundyDark,
    onPrimaryContainer = Color.White,
    secondary = GoldSoft,
    onSecondary = TextDark,
    secondaryContainer = Color(0xFF3A2D19),
    onSecondaryContainer = GoldSoft,
    tertiary = Color(0xFF2A313B),
    onTertiary = Color.White,
    background = Ink,
    onBackground = Color(0xFFF4EEE6),
    surface = InkSoft,
    onSurface = Color(0xFFF4EEE6),
    surfaceVariant = Color(0xFF2A3038),
    onSurfaceVariant = Color(0xFFC6BDB1),
    outline = Color(0xFF4B525B),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

@Composable
fun BeitAlHadayaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
