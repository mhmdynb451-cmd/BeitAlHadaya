package com.beitalhadaya.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.beitalhadaya.app.data.BotIntegration
import com.beitalhadaya.app.data.BotRepository
import com.beitalhadaya.app.data.CartItem
import com.beitalhadaya.app.data.CatalogRepository
import com.beitalhadaya.app.data.DeliveryAddress
import com.beitalhadaya.app.data.LocalBotRepository
import com.beitalhadaya.app.data.LocalOrderRepository
import com.beitalhadaya.app.data.LocalSettingsRepository
import com.beitalhadaya.app.data.Order
import com.beitalhadaya.app.data.OrderRepository
import com.beitalhadaya.app.data.OrderStatus
import com.beitalhadaya.app.data.PaymentMethod
import com.beitalhadaya.app.data.Product
import com.beitalhadaya.app.data.SettingsRepository
import com.beitalhadaya.app.data.StoreSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Home : Screen
    data object Notifications : Screen
    data object Wishlist : Screen
    data class Category(val categoryId: String) : Screen
    data class Product(val productId: String) : Screen
    data object Cart : Screen
    data object Checkout : Screen
    data object Orders : Screen
    data object Account : Screen
}

data class StoreUiState(
    val screen: Screen = Screen.Home,
    val categories: List<com.beitalhadaya.app.data.Category> = emptyList(),
    val products: List<Product> = emptyList(),
    val cart: List<CartItem> = emptyList(),
    val orders: List<Order> = emptyList(),
    val bots: List<BotIntegration> = emptyList(),
    val settings: StoreSettings = StoreSettings(),
    val favoriteIds: Set<String> = emptySet(),
    val searchQuery: String = "",
    val selectedPaymentMethod: PaymentMethod = PaymentMethod.CASH_ON_DELIVERY,
    val address: DeliveryAddress = DeliveryAddress("", "", "", "", ""),
    val infoMessage: String? = null
) {
    val cartCount: Int get() = cart.sumOf { it.quantity }
    val cartSubtotal: Int get() = cart.sumOf { it.lineTotal }
    val totalForCod: Int get() = cartSubtotal + settings.shippingFee
}

class StoreViewModel(
    private val catalogRepository: CatalogRepository,
    private val orderRepository: OrderRepository = LocalOrderRepository(),
    private val botRepository: BotRepository = LocalBotRepository(),
    private val settingsRepository: SettingsRepository = LocalSettingsRepository()
) : ViewModel() {
    private val _state = MutableStateFlow(StoreUiState())
    val state: StateFlow<StoreUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                catalogRepository.observeCategories(),
                catalogRepository.observeProducts(),
                orderRepository.observeOrders(),
                botRepository.observeBots(),
                settingsRepository.observeSettings()
            ) { categories, products, orders, bots, settings ->
                _state.value.copy(
                    categories = categories,
                    products = products,
                    orders = orders,
                    bots = bots,
                    settings = settings
                )
            }.collect { newState -> _state.value = newState }
        }
    }

    fun goHome() = _state.update { it.copy(screen = Screen.Home, infoMessage = null) }
    fun openCategory(id: String) = _state.update { it.copy(screen = Screen.Category(id), searchQuery = "", infoMessage = null) }
    fun openProduct(id: String) = _state.update { it.copy(screen = Screen.Product(id), infoMessage = null) }
    fun openCart() = _state.update { it.copy(screen = Screen.Cart, infoMessage = null) }
    fun openCheckout() = startCheckout()
    fun openOrders() = _state.update { it.copy(screen = Screen.Orders, infoMessage = null) }
    fun openAccount() = _state.update { it.copy(screen = Screen.Account, infoMessage = null) }
    fun openNotifications() = _state.update { it.copy(screen = Screen.Notifications, infoMessage = null) }
    fun openWishlist() = _state.update { it.copy(screen = Screen.Wishlist, infoMessage = null) }

    fun back() {
        when (val screen = _state.value.screen) {
            Screen.Home, Screen.Orders, Screen.Account, Screen.Notifications, Screen.Wishlist -> goHome()
            is Screen.Category -> goHome()
            is Screen.Product -> {
                val category = _state.value.products.firstOrNull { it.id == screen.productId }?.categoryId
                if (category == null) goHome() else openCategory(category)
            }
            Screen.Cart, Screen.Checkout -> goHome()
        }
    }

    fun updateSearch(value: String) = _state.update { it.copy(searchQuery = value) }

    fun toggleFavorite(productId: String) = _state.update { current ->
        val next = if (productId in current.favoriteIds) current.favoriteIds - productId else current.favoriteIds + productId
        current.copy(favoriteIds = next)
    }

    fun addToCart(product: Product) {
        if (!product.isActive || product.stock <= 0) {
            _state.update { it.copy(infoMessage = "هذا المنتج غير متاح حاليًا.") }
            return
        }
        _state.update { current ->
            val existing = current.cart.firstOrNull { it.product.id == product.id }
            val newCart = if (existing == null) current.cart + CartItem(product, 1)
            else current.cart.map { line -> if (line.product.id == product.id) line.copy(quantity = (line.quantity + 1).coerceAtMost(product.stock)) else line }
            current.copy(cart = newCart, infoMessage = "تمت إضافة المنتج إلى السلة")
        }
    }

    fun increase(item: CartItem) = addToCart(item.product)
    fun decrease(item: CartItem) = _state.update { current ->
        current.copy(cart = current.cart.mapNotNull { line ->
            when {
                line.product.id != item.product.id -> line
                line.quantity > 1 -> line.copy(quantity = line.quantity - 1)
                else -> null
            }
        })
    }
    fun removeFromCart(id: String) = _state.update { it.copy(cart = it.cart.filterNot { item -> item.product.id == id }) }

    fun startCheckout() {
        if (_state.value.cart.isEmpty()) _state.update { it.copy(infoMessage = "السلة فارغة. أضف منتجًا أولًا.") }
        else _state.update { it.copy(screen = Screen.Checkout, infoMessage = null) }
    }

    fun selectPaymentMethod(method: PaymentMethod) = _state.update { it.copy(selectedPaymentMethod = method, infoMessage = null) }
    fun updateAddress(fullName: String? = null, phone: String? = null, governorate: String? = null, city: String? = null, details: String? = null) {
        _state.update { current ->
            val a = current.address
            current.copy(address = a.copy(
                fullName = fullName ?: a.fullName,
                phone = phone ?: a.phone,
                governorate = governorate ?: a.governorate,
                city = city ?: a.city,
                details = details ?: a.details
            ))
        }
    }

    fun confirmOrder() {
        val current = _state.value
        if (current.cart.isEmpty()) return
        val a = current.address
        if (a.fullName.isBlank() || a.phone.isBlank() || a.governorate.isBlank() || a.city.isBlank() || a.details.isBlank()) {
            _state.update { it.copy(infoMessage = "أكمل الاسم ورقم الهاتف والمدينة والعنوان قبل تأكيد الطلب") }
            return
        }
        if (current.selectedPaymentMethod != PaymentMethod.CASH_ON_DELIVERY) {
            _state.update { it.copy(infoMessage = "طريقة الدفع محفوظة في الواجهة، وسيتم تفعيلها بعد ربط بوابة الدفع الآمنة بالخادم") }
            return
        }
        val deposit = current.settings.codDeposit
        val shipping = current.settings.shippingFee
        val order = Order(
            id = "BH-${System.currentTimeMillis().toString().takeLast(8)}",
            items = current.cart,
            subtotal = current.cartSubtotal,
            shipping = shipping,
            codDeposit = deposit,
            totalDueNow = deposit,
            amountDueOnDelivery = current.cartSubtotal + shipping,
            paymentMethod = current.selectedPaymentMethod,
            status = OrderStatus.CONFIRMED,
            address = a,
            createdAtEpochMs = System.currentTimeMillis()
        )
        viewModelScope.launch {
            orderRepository.save(order)
            _state.update { it.copy(screen = Screen.Orders, cart = emptyList(), infoMessage = "تم تسجيل طلبك ${order.id} بنجاح") }
        }
    }

    fun clearMessage() = _state.update { it.copy(infoMessage = null) }

    class Factory(
        private val repository: CatalogRepository,
        private val orders: OrderRepository = LocalOrderRepository(),
        private val bots: BotRepository = LocalBotRepository(),
        private val settings: SettingsRepository = LocalSettingsRepository()
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            StoreViewModel(repository, orders, bots, settings) as T
    }
}
