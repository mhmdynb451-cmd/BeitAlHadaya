# بيت الهدايا غاوي خسارة — Deep Audit / V1.2.1 Foundation

## Baseline inspected
- Current GitHub main build: Run #31 — success.
- Current repository build source is the small v0.3 project zip.
- The newer saved V1.2 project was inspected as the stronger engineering baseline.

## What V1.2 already provides
- Jetpack Compose + Material 3.
- ViewModel + StateFlow + Repository/Data layer.
- RTL onboarding and terms/privacy consent.
- Dynamic category model with parentId/sortOrder/isActive.
- Product model prepared for image URL, stock, SKU, sizes, colors and old price.
- Favorites, cart, checkout, orders, notifications and account screens.
- COD flow with configurable deposit; default deposit 100 EGP.
- Secure backend contracts for future authentication/catalog/orders/payments/AI.
- API 36 compile/target and Java 17.

## Intentional current limitations
- Product data is empty in the local catalog so the owner can add real products later.
- Card/Vodafone Cash are UI-ready only until a secure server-side gateway is connected.
- AI bots are contracts/repository scaffolding only; secrets must stay server-side.
- Local repositories are in-memory and therefore are not yet production persistence.

## Corrections in V1.2.1
- COD address validation now requires governorate as well as name, phone, city and details.
- Order cards now display the actual full order total separately from COD amount due on delivery.
- Version bumped to 1.2.1 / versionCode 5.

## Next engineering layers after this foundation
1. Real persistent local cache (Room/DataStore where appropriate).
2. HTTPS backend + authentication + server-side catalog/order APIs.
3. Real image storage/CDN and product image rendering.
4. Payment gateway for Visa/Mastercard and Vodafone Cash.
5. Owner/admin control plane, separate from the customer app.
6. Separate customer support bot and owner/product-management bot permissions.
7. Release signing, AAB, Play Console privacy/Data Safety, and production testing.
