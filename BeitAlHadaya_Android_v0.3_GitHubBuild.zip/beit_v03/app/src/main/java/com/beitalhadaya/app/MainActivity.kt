package com.beitalhadaya.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.CompositionLocalProvider

private val Ivory = Color(0xFFF6F1E8)
private val SurfaceIvory = Color(0xFFFFFCF7)
private val Navy = Color(0xFF18283A)
private val WarmGray = Color(0xFF8B8176)
private val Gold = Color(0xFF9B8765)
private val Ink = Color(0xFF2E2B28)

private val AppColors = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    secondary = WarmGray,
    onSecondary = Color.White,
    tertiary = Gold,
    background = Ivory,
    onBackground = Ink,
    surface = SurfaceIvory,
    onSurface = Ink
)

data class Category(val id: String, val name: String)
data class Product(val id: String, val name: String, val categoryId: String, val price: Double, val description: String = "", val options: List<String> = emptyList())
data class Address(val name: String, val phone: String, val city: String, val details: String)
data class Order(val id: String, val total: Double, val payment: String, val address: Address)

data class AppState(
    val screen: String = "categories",
    val selectedCategory: Category? = null,
    val selectedProduct: Product? = null,
    val cart: List<Product> = emptyList(),
    val address: Address? = null,
    val orders: List<Order> = emptyList(),
    val loggedIn: Boolean = false,
    val guest: Boolean = false
)

val categories = listOf(
    Category("women_clothes", "ملابس حريمي"), Category("men_clothes", "ملابس رجالي"),
    Category("kids_clothes", "ملابس أطفال"), Category("women_shoes", "أحذية حريمي"),
    Category("men_shoes", "أحذية رجالي"), Category("kids_shoes", "أحذية أطفال"),
    Category("school", "مستلزمات مدرسية"), Category("bags", "شنط وإكسسوارات"),
    Category("home", "مستلزمات منزلية"), Category("bridal", "مستلزمات عرايس")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { StoreApp() } }
}

@Composable
fun StoreApp() {
    var state by remember { mutableStateOf(AppState()) }
    // No fake inventory: products remain empty until the future admin/product workflow populates them.
    val products = remember { mutableStateListOf<Product>() }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = AppColors) {
            Scaffold(topBar = {
                TopAppBar(
                    title = { Text("بيت الهدايا غاوي خسارة", fontWeight = FontWeight.Bold) },
                    actions = {
                        TextButton(onClick = { state = state.copy(screen = "cart") }) { Text("السلة (${state.cart.size})") }
                        TextButton(onClick = { state = state.copy(screen = "orders") }) { Text("طلباتي") }
                    }
                )
            }) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (state.screen) {
                        "categories" -> CategoryScreen { state = state.copy(selectedCategory = it, screen = "products") }
                        "products" -> ProductListScreen(state.selectedCategory!!, products.filter { it.categoryId == state.selectedCategory!!.id }, { state = state.copy(screen = "categories") }) { p -> state = state.copy(selectedProduct = p, screen = "details") }
                        "details" -> ProductDetailsScreen(state.selectedProduct!!, { state = state.copy(screen = "products") }) { state = state.copy(cart = state.cart + state.selectedProduct!!) }
                        "cart" -> CartScreen(state.cart, { state = state.copy(screen = "categories") }, { p -> state = state.copy(cart = state.cart.toMutableList().also { it.remove(p) }) }) { state = state.copy(screen = if (state.loggedIn || state.guest) "address" else "login") }
                        "login" -> LoginScreen({ state = state.copy(loggedIn = true, screen = "address") }, { state = state.copy(guest = true, screen = "address") })
                        "address" -> AddressScreen(state.address, { a -> state = state.copy(address = a, screen = "checkout") }, { state = state.copy(screen = "cart") })
                        "checkout" -> CheckoutScreen(state.cart, state.address!!, { payment ->
                            val total = state.cart.sumOf { it.price }
                            val order = Order("BH-${state.orders.size + 1}", total, payment, state.address!!)
                            state = state.copy(orders = state.orders + order, cart = emptyList(), screen = "order_done")
                        }, { state = state.copy(screen = "address") })
                        "order_done" -> OrderDoneScreen(state.orders.lastOrNull(), { state = state.copy(screen = "categories") })
                        "orders" -> OrdersScreen(state.orders, { state = state.copy(screen = "categories") })
                    }
                }
            }
        }
    }
}

@Composable fun CategoryScreen(onCategory: (Category) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("الأقسام", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("أقسام منفصلة وقابلة لإضافة أقسام جديدة لاحقًا.")
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(categories) { c -> Card(Modifier.fillMaxWidth().clickable { onCategory(c) }) { Box(Modifier.height(110.dp).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(c.name, fontWeight = FontWeight.Bold) } } }
        }
    }
}

@Composable fun ProductListScreen(category: Category, products: List<Product>, onBack: () -> Unit, onProduct: (Product) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Button(onClick = onBack) { Text("رجوع") }; Spacer(Modifier.width(12.dp)); Text(category.name, style = MaterialTheme.typography.headlineSmall) }
        Spacer(Modifier.height(16.dp))
        if (products.isEmpty()) Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("لا توجد منتجات مضافة لهذا القسم حتى الآن.", fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text("المنتجات الفعلية ستُضاف من لوحة الإدارة/بوت المنتجات لاحقًا.") } }
        else LazyVerticalGrid(columns = GridCells.Fixed(2)) { items(products) { p -> Card(Modifier.padding(6.dp).clickable { onProduct(p) }) { Column(Modifier.padding(12.dp)) { Text(p.name, fontWeight = FontWeight.Bold); Text("${p.price} جنيه") } } } }
    }
}

@Composable fun ProductDetailsScreen(product: Product, onBack: () -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) { Button(onClick = onBack) { Text("رجوع") }; Spacer(Modifier.height(20.dp)); Text(product.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Text("${product.price} جنيه", style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(16.dp)); Text(if (product.description.isBlank()) "وصف المنتج سيُضاف من لوحة الإدارة." else product.description); Spacer(Modifier.height(24.dp)); Button(onClick = onAdd, Modifier.fillMaxWidth()) { Text("أضف للسلة") } }
}

@Composable fun CartScreen(cart: List<Product>, onBack: () -> Unit, onRemove: (Product) -> Unit, onCheckout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Button(onClick = onBack) { Text("متابعة التسوق") }; Spacer(Modifier.width(12.dp)); Text("السلة", style = MaterialTheme.typography.headlineSmall) }
        Spacer(Modifier.height(16.dp))
        if (cart.isEmpty()) Text("السلة فارغة حاليًا.") else { val total = cart.sumOf { it.price }; LazyColumn(Modifier.weight(1f)) { items(cart) { p -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text(p.name, fontWeight = FontWeight.Bold); Text("${p.price} جنيه") }; TextButton(onClick = { onRemove(p) }) { Text("حذف") } } } } }; HorizontalDivider(); Spacer(Modifier.height(10.dp)); Text("الإجمالي: ${total} جنيه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Button(onClick = onCheckout, Modifier.fillMaxWidth()) { Text("إتمام الطلب") } }
    }
}

@Composable fun LoginScreen(onLogin: () -> Unit, onGuest: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(40.dp)); Text("تسجيل الدخول", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text("تسجيل الدخول الفعلي بالـ OTP سيتم ربطه بالخادم لاحقًا."); Spacer(Modifier.height(24.dp)); OutlinedTextField(value = "", onValueChange = {}, label = { Text("رقم الموبايل") }, enabled = false, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); Button(onClick = onLogin, Modifier.fillMaxWidth()) { Text("متابعة كتسجيل دخول تجريبي") }; Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = onGuest, Modifier.fillMaxWidth()) { Text("الدخول كضيف") }
    }
}

@Composable fun AddressScreen(current: Address?, onSave: (Address) -> Unit, onBack: () -> Unit) {
    var name by remember(current) { mutableStateOf(current?.name ?: "") }; var phone by remember(current) { mutableStateOf(current?.phone ?: "") }; var city by remember(current) { mutableStateOf(current?.city ?: "") }; var details by remember(current) { mutableStateOf(current?.details ?: "") }
    Column(Modifier.fillMaxSize().padding(20.dp)) { Button(onClick = onBack) { Text("رجوع") }; Spacer(Modifier.height(16.dp)); Text("عنوان التوصيل", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); OutlinedTextField(name, { name = it }, label = { Text("الاسم") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)); OutlinedTextField(phone, { phone = it }, label = { Text("رقم الموبايل") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)); OutlinedTextField(city, { city = it }, label = { Text("المحافظة / المدينة") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)); OutlinedTextField(details, { details = it }, label = { Text("العنوان بالتفصيل") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(18.dp)); Button(onClick = { onSave(Address(name, phone, city, details)) }, enabled = name.isNotBlank() && phone.isNotBlank() && city.isNotBlank() && details.isNotBlank(), Modifier.fillMaxWidth()) { Text("حفظ ومتابعة للدفع") } }
}

@Composable fun CheckoutScreen(cart: List<Product>, address: Address, onConfirm: (String) -> Unit, onBack: () -> Unit) {
    var payment by remember { mutableStateOf("الدفع عند الاستلام") }; val total = cart.sumOf { it.price }
    Column(Modifier.fillMaxSize().padding(20.dp)) { Button(onClick = onBack) { Text("تعديل العنوان") }; Spacer(Modifier.height(16.dp)); Text("مراجعة الطلب", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Text("العنوان: ${address.city} — ${address.details}"); Spacer(Modifier.height(12.dp)); Text("الإجمالي: ${total} جنيه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(18.dp)); Text("طريقة الدفع", fontWeight = FontWeight.Bold); listOf("الدفع عند الاستلام", "InstaPay", "Vodafone Cash", "بطاقة بنكية").forEach { option -> Row(Modifier.fillMaxWidth().clickable { payment = option }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = payment == option, onClick = { payment = option }); Text(option) } }; Spacer(Modifier.height(12.dp)); Text("الربط المالي الفعلي سيحتاج بيانات بوابة الدفع/الحسابات في مرحلة التكامل.", style = MaterialTheme.typography.bodySmall); Spacer(Modifier.height(12.dp)); Button(onClick = { onConfirm(payment) }, Modifier.fillMaxWidth()) { Text("تأكيد الطلب") } }
}

@Composable fun OrderDoneScreen(order: Order?, onHome: () -> Unit) { Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Spacer(Modifier.height(50.dp)); Text("تم إنشاء الطلب", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); Text("رقم الطلب: ${order?.id ?: "-"}"); Text("الإجمالي: ${order?.total ?: 0.0} جنيه"); Text("الدفع: ${order?.payment ?: "-"}"); Spacer(Modifier.height(24.dp)); Button(onClick = onHome) { Text("العودة للمتجر") } } }

@Composable fun OrdersScreen(orders: List<Order>, onBack: () -> Unit) { Column(Modifier.fillMaxSize().padding(16.dp)) { Button(onClick = onBack) { Text("رجوع") }; Spacer(Modifier.height(12.dp)); Text("طلباتي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); if (orders.isEmpty()) Text("لا توجد طلبات حتى الآن.") else LazyColumn { items(orders) { o -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Column(Modifier.padding(14.dp)) { Text(o.id, fontWeight = FontWeight.Bold); Text("${o.total} جنيه — ${o.payment}"); Text("${o.address.city} — ${o.address.details}") } } } } } }
