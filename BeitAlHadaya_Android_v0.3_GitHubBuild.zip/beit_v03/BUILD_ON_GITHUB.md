# إخراج APK بسرعة

المشروع مجهز بملف GitHub Actions في `.github/workflows/build-apk.yml`.

بعد رفع المشروع إلى GitHub وتشغيل Workflow باسم **Build Android APK**، سيُبنى ملف:
`app/build/outputs/apk/debug/app-debug.apk`

وسيظهر أيضًا كـ Artifact باسم **BeitAlHadaya-debug-apk** يمكن تنزيله من صفحة التشغيل.

ملاحظات:
- هذا Debug APK للتجربة والتثبيت على الهاتف.
- إصدار المتجر الإنتاجي يحتاج توقيع Release بمفتاح خاص لا ينبغي مشاركته في المحادثة.
- التطبيق حاليًا لا يحتوي Backend/OTP/دفع حقيقي/لوحة إدارة.
